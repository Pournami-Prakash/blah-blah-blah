import { useEffect, useState } from 'react';
import LetterCard from './cards/LetterCard';
import PolaroidCard from './cards/PolaroidCard';
import TypewriterCard from './cards/TypewriterCard';
import CafeCard from './cards/CafeCard';
import JournalCard from './cards/JournalCard';
import ActivityCard from './cards/ActivityCard';
import { getPosts } from '../../api/client';
import type { Post, PostType } from '../../types';

type FilterType = 'all' | PostType;

function renderCard(post: Post) {
  switch (post.type) {
    case 'letter': return <LetterCard post={post} />;
    case 'polaroid': return <PolaroidCard post={post} />;
    case 'typewriter': return <TypewriterCard post={post} />;
    case 'cafe': return <CafeCard post={post} />;
    case 'journal': return <JournalCard post={post} />;
    case 'activity': return <ActivityCard post={post} />;
  }
}

export default function WhisperWall() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [filter, setFilter] = useState<FilterType>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getPosts(filter === 'all' ? {} : { type: filter as PostType })
      .then(setPosts)
      .finally(() => setLoading(false));
  }, [filter]);

  const filteredPosts = filter === 'all' ? posts : posts.filter(p => p.type === filter);

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{
          fontFamily: '"Playfair Display"', fontStyle: 'italic',
          fontSize: '28px', color: '#2A2420', marginBottom: '20px',
        }}>
          explore
        </h1>

        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {(['all', 'letter', 'polaroid', 'typewriter', 'cafe', 'journal', 'activity'] as FilterType[]).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              style={{
                background: filter === f ? '#2A2420' : 'white',
                color: filter === f ? '#F7F3EE' : '#2A2420',
                border: `.5px solid ${filter === f ? '#2A2420' : '#E8E0D4'}`,
                borderRadius: '12px', padding: '8px 14px',
                fontSize: '12px', fontFamily: '"DM Sans"',
                cursor: 'pointer', transition: 'all .15s',
                textTransform: 'capitalize',
              }}
            >
              {f === 'all' ? 'all' : f}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#8A7A6A' }}>
          loading posts…
        </div>
      ) : filteredPosts.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#8A7A6A' }}>
          nothing here yet
        </div>
      ) : (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
          gap: '20px',
        }}>
          {filteredPosts.map(post => (
            <div key={post.id}>{renderCard(post)}</div>
          ))}
        </div>
      )}
    </div>
  );
}
