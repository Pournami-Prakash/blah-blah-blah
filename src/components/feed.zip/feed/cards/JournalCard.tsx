import type { JournalPost } from '../../../types';

interface JournalCardProps {
  post: JournalPost;
}

export default function JournalCard({ post }: JournalCardProps) {
  return (
    <div className="journal-lines" style={{
      background: '#FDFCFA',
      border: '1px solid #E8E0D4',
      borderRadius: '12px',
      padding: '20px',
      boxShadow: '0 2px 8px rgba(42,36,32,0.04)',
      transition: 'all .2s',
    }}
      onMouseOver={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 4px 16px rgba(42,36,32,0.08)'; }}
      onMouseOut={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 2px 8px rgba(42,36,32,0.04)'; }}
    >
      {post.title && (
        <h3 style={{
          fontFamily: '"Playfair Display"', fontStyle: 'italic',
          fontSize: '15px', color: '#2A2420',
          marginBottom: '12px', fontWeight: 400,
        }}>
          {post.title}
        </h3>
      )}

      <p style={{
        fontSize: '13px', color: '#2A2420', lineHeight: '1.8',
        whiteSpace: 'pre-wrap', fontFamily: 'Caveat', position: 'relative', zIndex: 1,
      }}>
        {post.content}
      </p>

      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginTop: '14px', paddingTop: '12px', borderTop: '1px solid #E8E0D4',
      }}>
        {post.location && (
          <span style={{ fontSize: '11px', color: '#B0A090', fontFamily: '"DM Mono"' }}>
            {post.location.city}
          </span>
        )}
        <span style={{ fontSize: '12px', color: '#8A7A6A', fontFamily: '"DM Mono"' }}>
          ♡ {post.likesCount}
        </span>
      </div>
    </div>
  );
}
