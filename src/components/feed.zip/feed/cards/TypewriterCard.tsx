import type { TypewriterPost } from '../../../types';

interface TypewriterCardProps {
  post: TypewriterPost;
}

export default function TypewriterCard({ post }: TypewriterCardProps) {
  return (
    <div style={{
      background: 'white',
      border: '1px solid #D8D0C4',
      borderRadius: '12px',
      overflow: 'hidden',
      boxShadow: '0 2px 8px rgba(42,36,32,0.04)',
      transition: 'all .2s',
    }}
      onMouseOver={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 4px 16px rgba(42,36,32,0.08)'; }}
      onMouseOut={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 2px 8px rgba(42,36,32,0.04)'; }}
    >
      <div style={{
        background: 'linear-gradient(135deg, #8898C4 0%, #7088B4 100%)',
        height: '6px',
      }} />

      <div style={{ padding: '20px' }}>
        <p style={{
          fontSize: '13px', fontFamily: '"DM Mono"', color: '#2A2420',
          lineHeight: '1.7', whiteSpace: 'pre-wrap', fontWeight: 300,
        }}>
          {post.content}
        </p>

        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          marginTop: '14px', paddingTop: '12px', borderTop: '1px solid #E8E0D4',
        }}>
          {post.location && (
            <span style={{ fontSize: '11px', color: '#B0A090', fontFamily: '"DM Mono"' }}>
              {post.location.city}
            </span>
          )}
          <span style={{ fontSize: '12px', color: '#8A7A6A', fontFamily: '"DM Mono"' }}>
            ♡ {post.likesCount}
          </span>
        </div>
      </div>
    </div>
  );
}
