import type { PolaroidPost } from '../../../types';

interface PolaroidCardProps {
  post: PolaroidPost;
}

function getRotationClass(id: string): string {
  const rotations = ['polaroid-rotate-1', 'polaroid-rotate-2', 'polaroid-rotate-3', 'polaroid-rotate-4', 'polaroid-rotate-5'];
  const hash = id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return rotations[hash % rotations.length];
}

export default function PolaroidCard({ post }: PolaroidCardProps) {
  const rotation = getRotationClass(post.id);

  return (
    <div className={rotation} style={{
      background: 'white',
      border: '8px solid white',
      borderBottom: '16px solid white',
      borderRadius: '2px',
      boxShadow: '0 4px 12px rgba(42,36,32,0.15)',
      overflow: 'hidden',
      transition: 'all .2s',
    }}
      onMouseOver={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 8px 20px rgba(42,36,32,0.2)'; }}
      onMouseOut={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 4px 12px rgba(42,36,32,0.15)'; }}
    >
      <img
        src={post.imageUrl}
        alt="polaroid"
        style={{
          width: '100%', height: '220px',
          objectFit: 'cover', display: 'block',
        }}
      />

      {post.caption && (
        <div style={{ padding: '12px 10px', minHeight: '40px' }}>
          <p style={{
            fontSize: '13px', fontFamily: 'Caveat', color: '#2A2420',
            lineHeight: '1.4',
          }}>
            {post.caption}
          </p>
        </div>
      )}

      <div style={{
        padding: '8px 10px', display: 'flex', justifyContent: 'space-between',
        borderTop: '1px solid #E8E0D4', fontSize: '11px',
      }}>
        {post.location && (
          <span style={{ color: '#8A7A6A', fontFamily: '"DM Mono"' }}>
            {post.location.city}
          </span>
        )}
        <span style={{ color: '#8A7A6A', fontFamily: '"DM Mono"' }}>
          ♡ {post.likesCount}
        </span>
      </div>
    </div>
  );
}
