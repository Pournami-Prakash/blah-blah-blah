import type { CafePost } from '../../../types';

interface CafeCardProps {
  post: CafePost;
}

export default function CafeCard({ post }: CafeCardProps) {
  return (
    <div style={{
      background: 'white',
      border: '1px solid #E8E0D4',
      borderRadius: '16px',
      overflow: 'hidden',
      boxShadow: '0 2px 8px rgba(42,36,32,0.04)',
      transition: 'all .2s',
    }}
      onMouseOver={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 4px 16px rgba(42,36,32,0.08)'; }}
      onMouseOut={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 2px 8px rgba(42,36,32,0.04)'; }}
    >
      {post.imageUrl && (
        <img
          src={post.imageUrl}
          alt={post.name}
          style={{
            width: '100%', height: '140px',
            objectFit: 'cover',
          }}
        />
      )}

      <div style={{ padding: '18px' }}>
        <h3 style={{
          fontSize: '15px', fontWeight: 600, color: '#2A2420',
          marginBottom: '8px',
        }}>
          {post.name}
        </h3>

        <p style={{
          fontSize: '13px', color: '#8A7A6A', lineHeight: '1.5',
          marginBottom: '12px',
        }}>
          {post.description}
        </p>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '12px' }}>
          {post.tags.map(tag => (
            <span
              key={tag}
              style={{
                fontSize: '11px', color: '#B0A090', fontFamily: '"DM Mono"',
                background: '#F0EBE0', padding: '4px 8px', borderRadius: '6px',
              }}
            >
              {tag}
            </span>
          ))}
        </div>

        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          paddingTop: '10px', borderTop: '1px solid #E8E0D4',
        }}>
          {post.location && (
            <span style={{ fontSize: '11px', color: '#B0A090', fontFamily: '"DM Mono"' }}>
              {post.location.city}
            </span>
          )}
          <span style={{ fontSize: '12px', color: '#8A7A6A', fontFamily: '"DM Mono"' }}>
            ♡ {post.likesCount}
          </span>
        </div>
      </div>
    </div>
  );
}
