import type { LetterPost } from '../../../types';

interface LetterCardProps {
  post: LetterPost;
}

export default function LetterCard({ post }: LetterCardProps) {
  return (
    <div style={{
      background: 'white',
      border: '1px solid #E8E0D4',
      borderRadius: '16px',
      padding: '24px',
      boxShadow: '0 2px 8px rgba(42,36,32,0.04)',
      transition: 'all .2s',
    }}
      onMouseOver={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 4px 16px rgba(42,36,32,0.08)'; }}
      onMouseOut={e => { const el = e.currentTarget as HTMLElement; el.style.boxShadow = '0 2px 8px rgba(42,36,32,0.04)'; }}
    >
      <h3 style={{
        fontFamily: '"Playfair Display"', fontStyle: 'italic',
        fontSize: '16px', color: '#2A2420',
        marginBottom: '12px', fontWeight: 400,
      }}>
        dear world,
      </h3>

      <p style={{
        fontSize: '14px', color: '#2A2420', lineHeight: '1.6',
        marginBottom: '16px', whiteSpace: 'pre-wrap',
      }}>
        {post.content}
      </p>

      {post.attribution && (
        <p style={{
          fontSize: '12px', color: '#8A7A6A', fontFamily: '"DM Mono"',
          marginBottom: '14px',
        }}>
          {post.attribution}
        </p>
      )}

      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        paddingTop: '12px', borderTop: '1px solid #E8E0D4',
      }}>
        {post.location && (
          <span style={{ fontSize: '11px', color: '#B0A090', fontFamily: '"DM Mono"' }}>
            {post.location.city}
          </span>
        )}
        <span style={{ fontSize: '12px', color: '#8A7A6A', fontFamily: '"DM Mono"' }}>
          ♡ {post.likesCount}
        </span>
      </div>
    </div>
  );
}
